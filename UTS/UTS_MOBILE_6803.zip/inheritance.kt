open class Valorant{
    fun valorantIdentity(){
        println("Valorant Riot Games")
    }
}
open class Agent: Valorant(){
    fun agentIdentity(){
        println("We have so many agents")
    }
}
class GamesMode: Agent(){
    fun gamesvariantIdentity(){
        println("There is Unrated, Competitive, Spike Rush, Replication and many more")
    }
}
fun main() {
    val value = GamesMode()
    value.valorantIdentity()
    value.agentIdentity()
    value.gamesvariantIdentity()
}