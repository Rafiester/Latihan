class valorantGame {
    val name1: String = "Vandal"
    val name2: String = "Phantom"

    fun printSenjata() {
        println("Recoil $name1 terlalu tinggi, gunakan $name2 sebagai alternatif")
    }
}

fun main() {
    val value = valorantGame()
    value.printSenjata()
}